# "archive/__init__.py" from libWiiPy by NinjaCheetah & Contributors
# https://github.com/NinjaCheetah/libWiiPy

from .ash import *
from .lz77 import *
from .u8 import *
